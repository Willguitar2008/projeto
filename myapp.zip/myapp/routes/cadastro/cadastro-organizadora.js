let express = require('express');
let router = express.Router();
var Database = require('../../database');
var isNull = require('../../script').isNull;
const config = require('../../config');

router.get('/', function (req, res, next) {
    res.render('cadastro/cadastro-organizadora');
});

router.post('/nova-organizadora', (req, res, next) => {
    console.log('Tentando cadastrar usuário...');

    console.log(req.body);


    let usuario = req.body.usuarioOrganizadora;
    let email = req.body.emailOrganizadora;
    let senha = req.body.senhaOrganizadora;
    let cnpj = req.body.cnpjaOrganizadora;
    let endereco = req.body.enderecoOrganizadora;
    let empresa = req.body.empresaOrganizadora;
    let telefone = req.body.telefoneOrganizadora;

    console.log(usuario, email,senha, cnpj,endereco,empresa,telefone );

    if (isNull(nome) || isNull(login) || isNull(senha) || isNull(empresa)) {

        console.log('Algum dos campos não foi preenchido');
        return;
    } else {

        console.log("tentando acesso ao banco de dados...")
        Database.query(`insert into usuario values ('${usuario}', '${email}', '${senha}', 7 , 1 , ${cnpj}, ${endereco}, ${empresa}, ${telefone});`)
            .then(resultados => {
                console.log(resultados);
                res.status(200).redirect('/dashboard');

            })
    }
});

module.exports = router;
